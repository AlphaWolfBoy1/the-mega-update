Licenses: code LGPL 2.1 media CC BY-SA 3.0
Created by: UjEdwin
Date: 2016-03-29

See and or take items from players main inventory.
The invhack privilege requires to take items.

Tool: invhack:tool